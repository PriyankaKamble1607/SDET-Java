package JavaActivity1;

public class Car 
{

	String color;
    String transmission;
	int make;
	int tyres;
	int doors; 
	public Car() 
	{
		int tyres=4;
		int doors=4; 
	}
	
		public void DisplayCharacteristics() 
		{
			System.out.println("color="+color);
			System.out.println("transmission="+transmission);
			System.out.println("make="+make);
			System.out.println("tyres="+tyres);
			System.out.println("dors="+doors);
			
		}
		
		public void accelarate()
		{
			System.out.println("Car is moving forward");
		}
		
		public void brake()
		{
			System.out.println("Car has stopped");
		}

	

}
