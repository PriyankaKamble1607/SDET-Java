/**
 * 
 */
package JavaActivity1;

/**
 * @author PriyankaKamble
 *
 */
public class Activity1
{

	
	public static void main(String[] args)
	{
		Car carobj =new Car();

		carobj.make= 2014;
		carobj.color="Black";
		carobj.transmission= "Manual";
		carobj.DisplayCharacteristics();
		carobj.accelarate();
		carobj.brake();


	}

}
