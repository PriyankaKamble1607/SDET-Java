/**
 * 
 */
package Session1;

/**
 * @author PriyankaKamble
 *
 */
public class practice1 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char[] webSiteName = { 'W', 'E', 'B', 'S', 'I', 'T', 'E'};
		String webSite = new String(webSiteName);  
		System.out.println( webSite ); //OUTPUT: WEBSITE

	}

}
