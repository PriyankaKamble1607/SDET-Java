package JavaActivity4;

import java.util.Arrays;

public class Activity1_4
{

	public static void main(String[] args)
	{
		int[] numberArray= {2,6,0,3,5,10,3};
		
		//for(int number:sortArray)
		//System.out.println(Arrays.toString(sortArray));
		System.out.println("array before sorting:"+Arrays.toString(numberArray));
		sortArray(numberArray);
				
	}
	
	public static void sortArray(int[] numbers)
	{
		int i,j;
		//int sortedNumber=numbers[0];
		for(i=1;i<=numbers.length-1;i++)
		{
			int k= numbers[i];
			j=i-1;
			while(j>=0)
			{
				if(k < numbers[j])
					
					
				{
					numbers[j + 1] = numbers[j];
					--j;
				}
				numbers[j + 1] = k;
			}
			
		}
		System.out.println("Sorted Array="+Arrays.toString(numbers));
		
	}

}
