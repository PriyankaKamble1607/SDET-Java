package Activity2_1;

public class MyBook extends Book
{

	public void setTitle(String S) 
	{
		 title=S;
	}
	
	public static void main(String[] args)
	{
		String title="Monk who Sold his Ferrori";
		Book newNovel=new MyBook() ;
		
		//Use the setTitle() method to book title to the variable title.
		//Use the getTitle() method to print the name of the book
		newNovel.setTitle(title);
		String T=newNovel.getTitle();
		System.out.println("Book Title="+T);
		
	}
}
