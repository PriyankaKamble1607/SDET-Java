package Activity2_1;

abstract class Book 
{
	String title;
	//n abstract method setTitle() that takes one String argument.
	//a concrete method getTitle() that returns the value of title.
	
	abstract void setTitle(String booktitle);
	

	String getTitle()
	{
		return title;
	}
	

}
