package activity2_3;

public class Driver {

	public static void main(String[] args)
	{
		MountainBike bike =new MountainBike(3, 4, 30);
		bike.speedUp(1);
		bike.applyBrake(2);
		
		bike.bicycleDesc();
		bike.setHeight(34);
		
	}

}
