package activity2_3;

public class MountainBike extends Bicycle
{
	public int seatHeight;
	
   public MountainBike(int gears, int currentSpeed,int height)
    {
		super(gears, currentSpeed);
		seatHeight=height;
		
	}

   public void setHeight(int newValue) {
	    seatHeight = newValue;
	    System.out.println("New seat height:"+seatHeight);
	}
   
   public void bicycleDesc()
   {
	System.out.println("Seat Height:"+seatHeight);
   }
	

	

}
