package activity2_3;

interface BicycleParts
{
	
}
interface BicycleOperations
{
	
}

public class Bicycle implements BicycleParts,BicycleOperations
{

	public int gears;
	public int currentSpeed;
	
	public Bicycle(int gears, int currentSpeed) 
	{
		this.gears=gears;
		this.currentSpeed= currentSpeed;
	}
	
	public void applyBrake(int decrement) 
	{
		currentSpeed-=decrement;
		System.out.println("Break applied:Current speed:"+currentSpeed);
	}
	public void speedUp(int increment) 
	{
		currentSpeed+=increment;
		System.out.println("Speed has been increased to:"+currentSpeed);
	}

	public void bicycleDesc() 
	{
		System.out.println("number of gears"+ gears+"\t and the currentSpeed of the bicycle:"+currentSpeed);
	}
}
