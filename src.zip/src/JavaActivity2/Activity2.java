package JavaActivity2;

public class Activity2 
{


	public static void main(String[] args) 
	{
		
    int[] number= {10, 77, 10, 54, -11, 10};
    int Sum = Add(number);
    
    if(Sum==30)
        System.out.println("Sum is 30");
	else
    	System.out.println("Sum is not 30");
	}
	
	
	
	public static int Add(int[] num) 
	   {
		   int addition=0;
		  
	    //for(int i=0;i<=num.length-1;i++)
		   for(int nu :num)
	    {
	    	if(nu==10)
	    	{
	    		addition += nu;
	    	}
	    	
	    }
	    return addition;
	   }
}
