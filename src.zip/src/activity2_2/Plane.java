package activity2_2;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Plane
{
	private int maxPassengers;
	private List<String> Passengers;
	private Date lastTimeLanded;
	private Date lastTimeTAkeoff;
	
	public Plane(int maxPassengers)
	{
	
		this.maxPassengers = maxPassengers;
		this.Passengers = new ArrayList<>();
	}
	
	public void onboard(String Passengers)
	{
		
		this.Passengers.add(Passengers);
		
	}
	
	public Date takeOff()
	{
		this.lastTimeTAkeoff = new Date();
		return lastTimeTAkeoff;
	}
	
	public void land() 
	{
        this.lastTimeLanded = new Date();
        this.Passengers.clear();
	}
	
	public Date getLastTimeLanded()
	{
		return  lastTimeLanded;
	}
	public List<String> getPassesngers()
	{
		return Passengers;
	}
}
