package activity2_2;

public class EncapsulationActivity {

	public static void main(String[] args) throws InterruptedException 
	{
		Plane plane =new Plane(10);
		plane.onboard("Geeta");
		plane.onboard("Seeta");
		plane.onboard("Reeta");
		
		System.out.println("Plane take off time:"+plane.takeOff());
		
		System.out.println("Passengers in plane:"+plane.getPassesngers());
		plane.land();
		
		Thread.sleep(100000000);
		
		System.out.println("Landing time:"+plane.getLastTimeLanded());
	}

}
